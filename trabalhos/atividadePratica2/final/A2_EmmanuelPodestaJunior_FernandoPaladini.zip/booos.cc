#include <iostream>
#include "../lib/BOOOS.h"

using namespace std;
using namespace BOOOS;
BOOOS::BOOOS  _booos;


int main() {

	cout << "I'm a dummy app that does nothing..." << endl;

}
